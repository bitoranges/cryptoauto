
import React, { useState } from 'react';
import { Draft, DraftStatus } from '../types';

interface PublishedViewProps {
  drafts: Draft[];
  onUpdateLink: (id: string, url: string) => void;
}

const PublishedView: React.FC<PublishedViewProps> = ({ drafts, onUpdateLink }) => {
  const publishedDrafts = drafts.filter(d => d.status === DraftStatus.PUBLISHED).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempUrl, setTempUrl] = useState('');

  return (
    <div className="p-10 space-y-10 animate-in fade-in slide-in-from-right-8 h-full overflow-y-auto scrollbar-hide max-w-7xl mx-auto">
      <header className="flex items-end justify-between">
        <div className="space-y-2">
            <p className="label-sm text-slate-500">Archive / Historical Audit</p>
            <h2 className="display-hero">情报归档</h2>
        </div>
        <div className="glass-panel px-6 py-3 rounded-2xl border border-emerald-500/20">
           <span className="text-xl font-black text-emerald-400 italic">
            {publishedDrafts.length} <span className="text-[10px] font-bold uppercase ml-1">项情报已部署</span>
          </span>
        </div>
      </header>

      <div className="space-y-6">
        {publishedDrafts.map(draft => (
          <div key={draft.draft_id} className="glass-panel border border-white/5 rounded-[3rem] p-10 flex gap-10 group hover:border-white/10 transition-all shadow-2xl">
             <div className="w-16 h-16 rounded-[1.5rem] bg-slate-950 border border-white/5 flex items-center justify-center shrink-0 shadow-inner">
                <span className="text-3xl">{draft.tweet_url ? '📡' : '⏳'}</span>
             </div>
             <div className="flex-1 space-y-8">
                <div className="flex justify-between items-start">
                   <div className="space-y-2">
                      <div className="flex items-center gap-4">
                        <span className="text-[12px] font-black text-white uppercase tracking-tighter italic">情报部署核心 v1.1</span>
                        <span className="text-[11px] text-slate-600 font-mono uppercase">{new Date(draft.created_at).toLocaleString()}</span>
                      </div>
                      <div className="flex gap-2">
                         {draft.labels.map(l => (
                           <span key={l} className="text-[10px] bg-white/5 text-slate-500 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-white/5">#{l}</span>
                         ))}
                      </div>
                   </div>
                   {draft.tweet_url ? (
                     <a href={draft.tweet_url} target="_blank" rel="noreferrer" className="px-5 py-2 glass rounded-xl text-[11px] text-cyan-500 font-black hover:text-white uppercase tracking-widest transition-all">在 X 上核查 ↗</a>
                   ) : (
                     <div className="flex items-center gap-3">
                        {editingId === draft.draft_id ? (
                           <div className="flex gap-3 animate-in slide-in-from-right-4">
                              <input 
                                autoFocus
                                className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-[12px] text-slate-300 font-mono w-80 outline-none focus:border-cyan-500/50 shadow-inner"
                                placeholder="粘贴发布后的推文 URL..."
                                value={tempUrl}
                                onChange={(e) => setTempUrl(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') { onUpdateLink(draft.draft_id, tempUrl); setEditingId(null); setTempUrl(''); }
                                }}
                              />
                              <button onClick={() => { onUpdateLink(draft.draft_id, tempUrl); setEditingId(null); setTempUrl(''); }} className="bg-white text-slate-950 font-black px-4 py-2 rounded-xl text-[11px] uppercase tracking-widest shadow-xl">确认回写</button>
                           </div>
                        ) : (
                           <button onClick={() => setEditingId(draft.draft_id)} className="bg-amber-500/10 text-amber-500 border border-amber-500/20 px-6 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-amber-500 hover:text-slate-900 transition-all animate-pulse">待补充 X 链接</button>
                        )}
                     </div>
                   )}
                </div>
                <div className="p-8 bg-slate-950 rounded-[2.5rem] border border-white/5 text-[15px] text-slate-400 leading-relaxed font-medium italic shadow-inner">
                   "{draft.content}"
                </div>

                <div className="flex gap-16 pt-6 border-t border-white/5">
                   <div className="space-y-1">
                      <p className="label-sm !text-[0.55rem] text-slate-600">神经展示量 (Impressions)</p>
                      <p className="text-2xl font-black text-white italic tracking-tighter">{draft.performance?.impressions.toLocaleString() || '--'}</p>
                   </div>
                   <div className="space-y-1">
                      <p className="label-sm !text-[0.55rem] text-slate-600">神经互动 (Engagement)</p>
                      <p className="text-2xl font-black text-emerald-400 italic tracking-tighter">
                        {((draft.performance?.likes || 0) + (draft.performance?.retweets || 0) + (draft.performance?.bookmarks || 0)).toLocaleString()}
                      </p>
                   </div>
                   <div className="space-y-1">
                      <p className="label-sm !text-[0.55rem] text-slate-600">全链路转化得分</p>
                      <p className="text-2xl font-black text-indigo-400 italic tracking-tighter">{(Math.random() * 2 + 8).toFixed(1)} <span className="text-[10px] text-slate-700">/ 10</span></p>
                   </div>
                </div>
             </div>
          </div>
        ))}
        {publishedDrafts.length === 0 && (
          <div className="py-32 text-center opacity-30 italic">
             <div className="text-6xl mb-6">🗃️</div>
             <p className="label-sm tracking-[0.5em]">归档数据库为空</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PublishedView;
