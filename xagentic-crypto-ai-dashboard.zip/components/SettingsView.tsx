
import React from 'react';
import { CalibrationState, TaskState } from '../types';

interface SettingsViewProps {
  version: string;
  calibration: CalibrationState;
  setCalibration: React.Dispatch<React.SetStateAction<CalibrationState>>;
  tasks: TaskState[];
  onTriggerTask: (taskId: string) => void;
  onUpdateTaskInterval: (taskId: string, interval: number) => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ version, calibration, setCalibration, tasks, onTriggerTask, onUpdateTaskInterval }) => {
  return (
    <div className="p-10 h-full overflow-y-auto scrollbar-hide space-y-12 max-w-7xl mx-auto">
      <header className="space-y-2">
        <p className="label-sm text-slate-500">CORE ENGINE / TUNING</p>
        <h2 className="display-hero">神经校准</h2>
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-mono text-cyan-500 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20 uppercase">Version {version}</span>
          <span className="text-[10px] font-mono text-slate-700 italic">链路状态: 已锁定</span>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* 自适应阈值 */}
        <section className="glass-panel rounded-[2.5rem] p-10 space-y-10">
          <h3 className="section-title !text-sm text-slate-200">自适应感应参数</h3>
          <div className="space-y-10">
            {[
              { label: '影响力过滤门槛', key: 'impact_threshold', val: calibration.impact_threshold, color: 'bg-cyan-500' },
              { label: '核信度权重偏移', key: 'credibility_bias', val: Math.round(calibration.credibility_bias * 100), color: 'bg-indigo-500' }
            ].map(s => (
              <div key={s.key} className="space-y-4">
                <div className="flex justify-between items-end">
                  <span className="text-[12px] font-bold text-slate-400 uppercase tracking-widest">{s.label}</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-black italic text-white">{s.val}</span>
                    <span className="text-[10px] font-black text-slate-700 uppercase">/ 100</span>
                  </div>
                </div>
                <div className="flex gap-4 items-center">
                  <button onClick={() => setCalibration(p => ({...p, [s.key]: Math.max(0, (p[s.key] as any) - 5)}))} className="w-10 h-10 glass rounded-xl flex items-center justify-center text-xl text-white hover:bg-white/10 active:scale-90 transition-all">-</button>
                  <div className="flex-1 h-2 bg-slate-900 rounded-full overflow-hidden relative">
                    <div className={`absolute inset-y-0 left-0 ${s.color} rounded-full transition-all duration-500`} style={{ width: `${s.val}%` }}></div>
                  </div>
                  <button onClick={() => setCalibration(p => ({...p, [s.key]: Math.min(100, (p[s.key] as any) + 5)}))} className="w-10 h-10 glass rounded-xl flex items-center justify-center text-xl text-white hover:bg-white/10 active:scale-90 transition-all">+</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 调度流水线 */}
        <section className="glass-panel rounded-[2.5rem] p-10 space-y-8">
          <h3 className="section-title !text-sm text-slate-200">发现流水线调度</h3>
          <div className="space-y-3">
            {tasks.map(task => (
              <div key={task.id} className="glass-card p-5 rounded-2xl flex items-center justify-between group">
                <div className="flex items-center gap-6">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-[10px] ${task.status === 'boosted' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20' : 'bg-slate-900 text-slate-600'}`}>{task.label[0]}</div>
                  <div className="flex flex-col">
                    <span className="text-[13px] font-bold text-white italic tracking-tight">{task.label}</span>
                    <span className="text-[10px] font-mono text-slate-700 mt-1 uppercase">周期: {task.interval}MIN</span>
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onTriggerTask(task.id)} className="px-4 py-2 bg-white text-slate-950 rounded-lg text-[9px] font-black uppercase tracking-widest">单次脉冲</button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* 链路架构 */}
      <section className="glass-panel rounded-[3rem] p-12 space-y-10">
        <h3 className="section-title !text-sm text-center tracking-[0.4em] text-slate-500">神经协议架构 (Architecture)</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { id: '01', name: 'Classifier', model: 'Gemini 3 Flash', detail: '语义解析' },
            { id: '02', name: 'Verifier', model: 'Gemini 3 Pro', detail: '真伪锚定' },
            { id: '03', name: 'Analyst', model: 'Gemini 3 Pro', detail: '价值推演' },
            { id: '04', name: 'Judge', model: 'Gemini 3 Flash', detail: '风险判定' }
          ].map((node) => (
            <div key={node.id} className="glass-card p-8 rounded-[2rem] flex flex-col items-center text-center space-y-4 group hover:border-cyan-500/40 transition-all">
              <span className="text-3xl font-black text-white/5 group-hover:text-cyan-500/10 transition-colors italic">{node.id}</span>
              <div className="space-y-1">
                <h4 className="text-[12px] font-black text-cyan-400 uppercase tracking-widest">{node.name}</h4>
                <p className="text-[11px] font-bold text-white italic">{node.model}</p>
                <p className="text-[9px] text-slate-700 uppercase mt-2">{node.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default SettingsView;
