
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Signal, Draft, DraftStatus, Track, Lane, Story } from '../types';
import { connectLiveAudit, createAudioBlob, decodeBase64, decodeAudioToBuffer } from '../services/geminiService';

interface ReviewDeskProps {
  signals: Signal[];
  drafts: Draft[];
  stories: Story[];
  onReview: (draftId: string, action: 'approve' | 'reject', reason?: string) => void;
  onEdit: (draftId: string, content: string) => void;
  onUpdateThread?: (draftId: string, threadItems: string[]) => void;
  onUpdateCounterCase?: (draftId: string, counterCase: string) => void;
  onToggleStar: (signalId: string, evidenceId: string) => void;
  onAskMoreEvidence: (signalId: string, query?: string) => void;
  onMergeStory: (storyId: string, targetStoryId: string) => void;
  onRegenerate: (draftId: string, feedback: string) => void;
  onUpdateClaims?: (signalId: string, claims: any[]) => void;
}

const ReviewDesk: React.FC<ReviewDeskProps> = ({ 
  signals, drafts, stories, onReview, onEdit, onUpdateThread, onUpdateCounterCase, onToggleStar, onAskMoreEvidence, onRegenerate, onMergeStory, onUpdateClaims
}) => {
  const [selectedSignalId, setSelectedSignalId] = useState<string | null>(signals[0]?.signal_id || null);
  const [activeTab, setActiveTab] = useState<'traffic' | 'research'>('traffic');
  const [isLiveOpen, setIsLiveOpen] = useState(false);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const selectedSignal = signals.find(s => s.signal_id === selectedSignalId);
  const selectedDraft = drafts.find(d => d.signal_id === selectedSignalId);

  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const liveSessionRef = useRef<any>(null);

  const filteredSignals = useMemo(() => signals.filter(s => {
    const d = drafts.find(dr => dr.signal_id === s.signal_id);
    return d?.track === activeTab && d?.status !== DraftStatus.PUBLISHED && d?.status !== DraftStatus.REJECTED;
  }), [signals, drafts, activeTab]);

  const handleStartLiveAudit = async () => {
    if (!selectedSignal || isLiveActive) return;
    setIsLiveOpen(true);
    setIsLiveActive(true);

    const inputCtx = new AudioContext({ sampleRate: 16000 });
    const outputCtx = new AudioContext({ sampleRate: 24000 });
    audioContextRef.current = outputCtx;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const sessionPromise = connectLiveAudit(selectedSignal, {
        onopen: () => {
          const source = inputCtx.createMediaStreamSource(stream);
          const processor = inputCtx.createScriptProcessor(4096, 1, 1);
          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            const pcmBlob = createAudioBlob(inputData);
            sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
          };
          source.connect(processor);
          processor.connect(inputCtx.destination);
        },
        onmessage: async (msg: any) => {
          const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audioData) {
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
            const buffer = await decodeAudioToBuffer(decodeBase64(audioData), outputCtx);
            const source = outputCtx.createBufferSource();
            source.buffer = buffer;
            source.connect(outputCtx.destination);
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += buffer.duration;
          }
        },
        onclose: () => setIsLiveActive(false),
        onerror: () => setIsLiveActive(false)
      });
      liveSessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsLiveActive(false);
    }
  };

  const stopLiveAudit = () => {
    if (liveSessionRef.current) liveSessionRef.current.close();
    setIsLiveOpen(false);
    setIsLiveActive(false);
  };

  return (
    <div className="flex h-full overflow-hidden bg-slate-950">
      {/* List Sidebar */}
      <div className="w-80 border-r border-white/5 bg-slate-900/10 flex flex-col shrink-0">
        <div className="p-4 border-b border-white/5 flex gap-2">
          {(['traffic', 'research'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all ${activeTab === tab ? 'bg-white text-slate-950' : 'text-slate-500 hover:bg-white/5'}`}>
              {tab === 'traffic' ? '流量池' : '投研池'}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-hide">
          {filteredSignals.map(signal => (
            <button key={signal.signal_id} onClick={() => { setSelectedSignalId(signal.signal_id); stopLiveAudit(); }} className={`w-full p-5 text-left border-b border-white/5 transition-all group ${selectedSignalId === signal.signal_id ? 'bg-cyan-500/5' : 'hover:bg-white/5'}`}>
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border ${signal.routing.lane === Lane.FAST ? 'border-amber-500/30 text-amber-500 bg-amber-500/5' : 'border-cyan-500/30 text-cyan-500 bg-cyan-500/5'}`}>{signal.routing.lane === Lane.FAST ? 'FAST' : 'SLOW'}</span>
                <span className="text-[9px] font-mono text-slate-700">{new Date(signal.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <h4 className={`text-[13px] font-bold leading-relaxed ${selectedSignalId === signal.signal_id ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`}>{signal.topic}</h4>
            </button>
          ))}
        </div>
      </div>

      {/* Review Main */}
      {selectedSignal ? (
        <div className="flex-1 flex flex-col min-w-0 relative">
          <div className="flex-1 overflow-y-auto p-12 scrollbar-hide">
            <div className="max-w-3xl mx-auto space-y-12 pb-24">
              <header className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="label-sm">核信度分析</span>
                    <div className="flex h-1.5 w-40 bg-slate-900 rounded-full overflow-hidden">
                      <div className="h-full bg-cyan-500 shadow-[0_0_12px_#06b6d4]" style={{ width: `${selectedSignal.verdict.confidence * 100}%` }}></div>
                    </div>
                    <span className="text-[11px] font-black text-cyan-400">{Math.round(selectedSignal.verdict.confidence * 100)}%</span>
                  </div>
                  <button onClick={handleStartLiveAudit} className="px-4 py-2 rounded-full border border-white/10 text-[10px] font-bold text-cyan-500 hover:bg-cyan-500 hover:text-slate-950 transition-all flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
                    实时神经审计
                  </button>
                </div>
                <h2 className="display-hero !text-3xl text-white italic uppercase tracking-tighter leading-none">{selectedSignal.topic}</h2>
              </header>

              {/* Grounding Sources */}
              <section className="space-y-4">
                <h3 className="label-sm text-slate-500">外部情报锚点 (Grounding)</h3>
                <div className="grid gap-3">
                  {selectedSignal.evidence.map(ev => (
                    <div key={ev.evidence_id} className="glass-card rounded-3xl p-6 flex gap-6 group hover:border-cyan-500/30 transition-all">
                      <div className="w-12 h-12 bg-slate-950 rounded-2xl flex items-center justify-center font-black text-cyan-500/50 shrink-0 text-xs border border-white/5">T{ev.source_tier}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="text-sm font-black text-slate-100 truncate italic">{ev.title}</h5>
                          <a href={ev.url} target="_blank" className="text-[10px] text-cyan-500 font-black uppercase tracking-widest shrink-0 ml-4 hover:underline">Verify ↗</a>
                        </div>
                        <p className="text-[12px] text-slate-500 italic leading-relaxed line-clamp-2">"{ev.snippet}"</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Analysis */}
              <div className="grid grid-cols-2 gap-6">
                <div className="glass-panel p-6 rounded-[2rem] space-y-2">
                  <p className="label-sm !text-[0.6rem] opacity-50">市场立场</p>
                  <p className={`text-xl font-black italic uppercase ${selectedSignal.analysis_output?.stance === 'bullish' ? 'text-emerald-400' : selectedSignal.analysis_output?.stance === 'bearish' ? 'text-rose-400' : 'text-slate-400'}`}>{selectedSignal.analysis_output?.stance}</p>
                </div>
                <div className="glass-panel p-6 rounded-[2rem] space-y-2">
                  <p className="label-sm !text-[0.6rem] opacity-50">Alpha 评分</p>
                  <p className="text-xl font-black italic text-white">{selectedSignal.analysis_output?.alpha_score}/10</p>
                </div>
              </div>
            </div>
          </div>

          {/* Review Actions */}
          <div className="glass-panel border-t border-white/5 p-8 backdrop-blur-3xl z-40">
            <div className="max-w-5xl mx-auto flex gap-8">
              <div className="flex-1 space-y-3">
                <div className="flex justify-between">
                  <span className="label-sm">情报部署文案</span>
                  <span className="text-[9px] font-mono text-slate-600 uppercase">Tokens: {selectedDraft?.content.length}</span>
                </div>
                <textarea className="w-full bg-slate-950 border border-white/5 rounded-3xl p-6 text-[14px] h-32 text-slate-300 italic focus:ring-1 focus:ring-cyan-500/20 outline-none resize-none leading-relaxed" value={selectedDraft?.content || ''} onChange={(e) => selectedDraft && onEdit(selectedDraft.draft_id, e.target.value)} />
              </div>
              <div className="w-64 flex flex-col gap-3 justify-end">
                <button onClick={() => selectedDraft && onReview(selectedDraft.draft_id, 'approve')} className="w-full h-14 bg-white text-slate-950 rounded-2xl font-black uppercase text-[12px] tracking-widest hover:bg-cyan-400 transition-all shadow-[0_20px_40px_rgba(255,255,255,0.05)]">核准部署</button>
                <button onClick={() => setIsRejectModalOpen(true)} className="w-full h-14 bg-slate-900 text-slate-500 rounded-2xl font-black uppercase text-[12px] tracking-widest hover:bg-rose-500/10 hover:text-rose-500 transition-all">终止信号</button>
              </div>
            </div>
          </div>

          {/* Live Audio Overlay */}
          {isLiveOpen && (
            <div className="absolute inset-0 z-50 bg-slate-950/90 backdrop-blur-2xl flex flex-col items-center justify-center p-12 animate-in fade-in zoom-in-95">
              <div className="relative w-48 h-48 mb-12">
                <div className="absolute inset-0 rounded-full bg-cyan-500/10 animate-ping"></div>
                <div className="absolute inset-4 rounded-full bg-cyan-500/20 animate-pulse"></div>
                <div className="absolute inset-8 rounded-full border border-cyan-500/40 flex items-center justify-center">
                  <div className="flex gap-1.5 items-end">
                    {[1, 2, 3, 4, 5].map(i => (
                      <div key={i} className={`w-1.5 bg-cyan-500 rounded-full transition-all duration-100 ${isLiveActive ? 'animate-bounce' : 'h-2'}`} style={{ height: isLiveActive ? `${Math.random() * 20 + 10}px` : '4px', animationDelay: `${i * 0.1}s` }}></div>
                    ))}
                  </div>
                </div>
              </div>
              <h3 className="text-2xl font-black text-white italic mb-2 uppercase tracking-tight">神经审计会话中...</h3>
              <p className="text-slate-500 text-sm mb-12 italic">"正在讨论: ${selectedSignal.topic}"</p>
              <button onClick={stopLiveAudit} className="px-12 py-4 bg-rose-500 text-white rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-rose-600 transition-all shadow-2xl">关闭审计链路</button>
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center opacity-10">
          <p className="label-sm tracking-[0.5em]">WAITING FOR PULSE</p>
        </div>
      )}
    </div>
  );
};

export default ReviewDesk;
