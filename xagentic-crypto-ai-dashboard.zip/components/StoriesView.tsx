
import React, { useState } from 'react';
import { Story, Signal, Stance, SignalMaturity } from '../types';
import { LineChart, Line, Tooltip, ResponsiveContainer } from 'recharts';
import { generateStoryVideo } from '../services/geminiService';

interface StoriesViewProps {
  stories: Story[];
  signals: Signal[];
  onUpdateSummary: (storyId: string, summary: string) => void;
  onDistill: (storyId: string) => void;
  onMergeStories: (sourceId: string, targetId: string) => void;
  onDeepDive: (storyId: string) => void;
  onUpdateStory: (storyId: string, updates: Partial<Story>) => void;
}

const StoriesView: React.FC<StoriesViewProps> = ({ stories, signals, onUpdateSummary, onDistill, onMergeStories, onDeepDive, onUpdateStory }) => {
  const [selectedStoryId, setSelectedStoryId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<string | null>(null);
  
  const selectedStory = stories.find(s => s.story_id === selectedStoryId);
  const storySignals = signals
    .filter(s => selectedStory?.signals.includes(s.signal_id))
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

  const chartData = storySignals.map(sig => ({
    time: new Date(sig.created_at).toLocaleTimeString(),
    stance: sig.analysis_output?.stance === Stance.BULLISH ? 100 : sig.analysis_output?.stance === Stance.BEARISH ? 0 : 50
  }));

  const handleGenerateVideo = async (story: Story) => {
    if (isGenerating) return;
    
    // Check API Key
    const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio?.openSelectKey();
      // Proceed assuming success as per PRD race condition rules
    }

    setIsGenerating(story.story_id);
    onUpdateStory(story.story_id, { is_generating_video: true });
    
    try {
      const videoUrl = await generateStoryVideo(story.title, story.summary);
      if (videoUrl) {
        onUpdateStory(story.story_id, { video_url: videoUrl, is_generating_video: false });
      }
    } catch (err) {
      console.error(err);
      onUpdateStory(story.story_id, { is_generating_video: false });
    } finally {
      setIsGenerating(null);
    }
  };

  return (
    <div className="p-10 h-full overflow-y-auto scrollbar-hide space-y-12 max-w-7xl mx-auto">
      <header className="flex items-end justify-between">
        <div className="space-y-2">
            <p className="label-sm text-slate-500">叙事生命周期存档 / NARRATIVE MEMORY</p>
            <h2 className="display-hero">叙事中心</h2>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {stories.map(story => (
          <div key={story.story_id} className="glass-card rounded-[3rem] overflow-hidden group flex flex-col h-[500px] border border-white/5 shadow-2xl transition-all hover:border-cyan-500/30">
            <div className="h-[220px] relative overflow-hidden shrink-0">
                {story.video_url ? (
                  <video src={story.video_url} autoPlay loop muted className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                ) : (
                  <img src={story.poster_url || 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0'} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                <div className="absolute top-8 left-8 flex gap-2">
                    <span className="px-4 py-1.5 bg-white text-slate-950 text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg">活跃叙事</span>
                    {story.video_url && <span className="px-4 py-1.5 bg-cyan-500 text-slate-950 text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg">VEO GENERATED</span>}
                </div>
            </div>
            <div className="p-10 flex-1 flex flex-col justify-between">
                <div className="space-y-4">
                  <h3 className="text-2xl font-black text-white italic tracking-tighter uppercase leading-none group-hover:text-cyan-400 transition-colors">{story.title}</h3>
                  <p className="text-[14px] text-slate-400 font-medium italic line-clamp-2 leading-relaxed">"{story.summary}"</p>
                </div>
                <div className="flex items-center gap-4 pt-8 border-t border-white/5 mt-auto">
                  <button onClick={() => setSelectedStoryId(story.story_id)} className="flex-1 h-14 bg-white text-slate-950 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-xl">展开叙事</button>
                  <button 
                    onClick={() => handleGenerateVideo(story)} 
                    disabled={!!story.video_url || isGenerating === story.story_id}
                    className={`h-14 px-8 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all ${story.video_url ? 'bg-slate-900 text-slate-500 opacity-50' : 'bg-slate-800 text-cyan-400 hover:bg-slate-700'}`}
                  >
                    {isGenerating === story.story_id ? '生成中...' : story.video_url ? '视频已就绪' : '生成 VEO 预告'}
                  </button>
                </div>
            </div>
          </div>
        ))}
      </div>

      {/* Story Overlay */}
      {selectedStory && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/98 backdrop-blur-3xl p-12 overflow-hidden">
          <div className="w-full h-full glass-panel rounded-[4rem] overflow-hidden flex flex-col relative border border-white/5 animate-in zoom-in-95">
            <button onClick={() => setSelectedStoryId(null)} className="absolute top-12 right-12 w-16 h-16 glass rounded-full flex items-center justify-center text-3xl text-white hover:bg-rose-500 transition-all z-50">✕</button>
            
            <div className="flex-1 overflow-hidden flex">
              <div className="flex-1 overflow-y-auto p-20 scrollbar-hide space-y-20">
                <header className="space-y-6">
                  <p className="label-sm text-cyan-500 tracking-[0.5em]">INTELLIGENCE REPORT / DEEP ARCHIVE</p>
                  <h3 className="display-hero text-white italic tracking-tighter uppercase leading-none">{selectedStory.title}</h3>
                  <div className="p-10 glass-card rounded-[2.5rem] text-xl text-slate-200 font-medium italic leading-relaxed shadow-inner">
                    {selectedStory.distilled_note || '叙事蒸馏中...'}
                  </div>
                </header>

                <section className="space-y-8">
                  <h4 className="label-sm text-slate-500 tracking-[0.3em]">神经立场演进曲线</h4>
                  <div className="h-96 glass-card rounded-[3rem] p-12">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <Line type="monotone" dataKey="stance" stroke="#06b6d4" strokeWidth={6} dot={{ r: 8, fill: '#06b6d4', strokeWidth: 0 }} />
                        <Tooltip content={() => null} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </section>
              </div>

              <div className="w-[450px] glass-panel border-l border-white/5 p-16 flex flex-col gap-12 overflow-y-auto scrollbar-hide">
                <div className="space-y-8">
                  <h5 className="label-sm text-cyan-400">叙事预告片</h5>
                  {selectedStory.video_url ? (
                    <video src={selectedStory.video_url} controls className="w-full rounded-[2.5rem] border border-white/10 shadow-2xl" />
                  ) : (
                    <div className="aspect-video bg-slate-900 rounded-[2.5rem] flex flex-col items-center justify-center p-8 text-center border border-dashed border-white/10">
                      <p className="text-xs text-slate-600 font-black uppercase mb-4">待生成视频预告</p>
                      <button onClick={() => handleGenerateVideo(selectedStory)} className="px-6 py-2 bg-slate-800 text-cyan-500 rounded-xl text-[10px] font-black uppercase tracking-widest">启动 VEO 引擎</button>
                    </div>
                  )}
                </div>

                <div className="space-y-8">
                  <h5 className="label-sm text-slate-500">脉冲事件流</h5>
                  <div className="space-y-4">
                    {storySignals.slice().reverse().map(sig => (
                      <div key={sig.signal_id} className="p-6 bg-white/5 rounded-3xl border border-white/5 group hover:border-cyan-500/30 transition-all">
                        <p className="text-[10px] font-mono text-slate-700 mb-2 uppercase">{new Date(sig.created_at).toLocaleString()}</p>
                        <p className="text-sm font-black text-slate-300 italic group-hover:text-cyan-400 leading-relaxed transition-colors">"{sig.topic}"</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                <button onClick={() => onDeepDive(selectedStory.story_id)} className="mt-auto w-full py-6 bg-white text-slate-950 rounded-[2rem] font-black uppercase text-[12px] tracking-widest shadow-2xl hover:bg-cyan-400 active:scale-95 transition-all">导出深度研报 ↗</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StoriesView;
