
import React, { useMemo } from 'react';
import { Signal, Draft, DraftStatus, SystemMetric, TaskState } from '../types';
import { ResponsiveContainer, AreaChart, Area, Tooltip } from 'recharts';

interface DashboardViewProps {
  signals: Signal[];
  drafts: Draft[];
  metrics: SystemMetric[];
  tasks: TaskState[];
  onRetract: (draftId: string) => void;
}

const DashboardView: React.FC<DashboardViewProps> = ({ signals, drafts, metrics, tasks, onRetract }) => {
  const pendingCount = drafts.filter(d => d.status === DraftStatus.DRAFT || d.status === DraftStatus.NEEDS_MORE_EVIDENCE).length;
  const approvedCount = drafts.filter(d => d.status === DraftStatus.PUBLISHED).length;
  const hitRate = signals.length > 0 ? Math.round((approvedCount / signals.length) * 100) : 0;
  
  const currentStats = metrics[metrics.length - 1] || { throughput: 14.5, system_health: 99.2 };

  const throughputData = useMemo(() => {
    return Array.from({ length: 12 }, (_, i) => ({
      time: `${i * 2}h`,
      val: Math.floor(Math.random() * 20) + 15
    }));
  }, []);

  return (
    <div className="p-10 h-full overflow-y-auto scrollbar-hide space-y-10 max-w-7xl mx-auto">
      <header className="flex items-end justify-between">
        <div>
          <p className="label-sm text-cyan-500 mb-1">NETWORK STATUS / OVERVIEW</p>
          <h2 className="display-hero">神经控制中心</h2>
        </div>
        <div className="flex gap-2">
          {tasks.map(t => (
            <div key={t.id} className="glass-panel px-4 py-2 rounded-xl flex items-center gap-2">
              <span className={`w-1.5 h-1.5 rounded-full ${t.status === 'boosted' ? 'bg-amber-400 animate-pulse' : 'bg-cyan-500 shadow-[0_0_8px_#06b6d4]'}`}></span>
              <span className="text-[11px] font-bold text-slate-300">{t.label}</span>
            </div>
          ))}
        </div>
      </header>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-2 glass-panel rounded-[2rem] p-8 flex flex-col justify-between overflow-hidden relative group">
          <div className="relative z-10">
            <p className="label-sm">吞吐量趋势分析</p>
            <h3 className="section-title mt-1">情报脉冲流</h3>
            <div className="mt-6 flex items-baseline gap-2">
              <span className="text-5xl font-black italic text-white tracking-tighter">28.4</span>
              <span className="text-xs font-bold text-slate-600">TPS</span>
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-0 h-32 -mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={throughputData}>
                <defs>
                  <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="val" stroke="#06b6d4" strokeWidth={3} fillOpacity={1} fill="url(#colorVal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card rounded-[2rem] p-8 flex flex-col justify-between">
          <p className="label-sm">命中率</p>
          <div>
            <p className="text-4xl font-black text-white italic">{hitRate}<span className="text-lg ml-1 text-slate-600">%</span></p>
            <p className="text-[11px] font-medium text-slate-500 mt-1">情报对齐效率</p>
          </div>
        </div>

        <div className="glass-card rounded-[2rem] p-8 flex flex-col justify-between border-l-4 border-l-cyan-500">
          <p className="label-sm">待审信号</p>
          <div>
            <p className="text-4xl font-black text-cyan-400 italic">{pendingCount}</p>
            <p className="text-[11px] font-medium text-slate-500 mt-1">待处理条目</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel rounded-[2rem] p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="section-title !text-sm">最新部署记录</h3>
            <button className="text-[10px] font-bold text-cyan-500 hover:text-white transition-colors">查看全部 →</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {drafts.filter(d => d.status === DraftStatus.PUBLISHED).slice(0, 4).map(draft => (
              <div key={draft.draft_id} className="glass-card rounded-2xl p-5 border-l-2 border-l-emerald-500 group">
                <div className="flex justify-between items-start mb-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-xs">📡</div>
                  <span className="text-[9px] font-mono text-slate-700">{new Date(draft.created_at).toLocaleTimeString()}</span>
                </div>
                <p className="text-[12px] font-bold text-slate-300 line-clamp-2 leading-relaxed italic">"{draft.content}"</p>
                <div className="mt-4 flex justify-end">
                   <button onClick={() => onRetract(draft.draft_id)} className="text-[9px] font-black text-rose-500/40 hover:text-rose-500 uppercase tracking-widest">撤回部署</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-[2rem] p-8 flex flex-col justify-between relative overflow-hidden group">
          <div className="space-y-6 relative z-10">
            <h3 className="section-title !text-sm">系统完整性</h3>
            <div className="flex items-center gap-4">
              <div className="relative w-20 h-20">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="40" cy="40" r="34" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-slate-900" />
                  <circle cx="40" cy="40" r="34" stroke="currentColor" strokeWidth="6" fill="transparent" strokeDasharray="213.6" strokeDashoffset={213.6 * (1 - currentStats.system_health / 100)} className="text-emerald-500" strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-black text-lg italic text-white">{currentStats.system_health}%</div>
              </div>
              <div>
                <p className="text-xs font-bold text-white uppercase">运行状态: 极佳</p>
                <p className="text-[10px] text-slate-600">无异常波动检测</p>
              </div>
            </div>
          </div>
          <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-cyan-500/5 blur-3xl rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
