
import React from 'react';

interface SidebarProps {
  currentView: string;
  onSetView: (view: string) => void;
  systemLogs: { msg: string, ts: string }[];
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onSetView, systemLogs }) => {
  const navItems = [
    { id: 'dashboard', label: '控制中心', sub: 'HUB', icon: 'M4 6h16M4 12h16M4 18h16' },
    { id: 'signals', label: '信号审核', sub: 'REVIEW', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
    { id: 'stories', label: '叙事管理', sub: 'NARRATIVE', icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
    { id: 'drafts', label: '部署审计', sub: 'ARCHIVE', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: 'settings', label: '核心配置', sub: 'CONFIG', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z' },
  ];

  return (
    <div className="w-64 bg-slate-950 border-r border-white/5 h-screen flex flex-col shrink-0">
      <div className="p-8 flex items-center gap-3">
        <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
          <svg className="w-5 h-5 text-slate-950" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <div>
          <h1 className="text-lg font-black tracking-tighter text-white">XAgentic</h1>
          <p className="label-sm !text-[0.55rem] -mt-1 opacity-50">神经操作系统</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onSetView(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              currentView === item.id 
                ? 'bg-white/5 text-cyan-400 border border-white/5 shadow-inner' 
                : 'text-slate-500 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <div className="text-left">
              <p className="text-[13px] font-bold leading-none">{item.label}</p>
              <p className="label-sm !text-[0.5rem] mt-0.5 opacity-40">{item.sub}</p>
            </div>
          </button>
        ))}
      </nav>

      <div className="p-6">
        <div className="glass-panel rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="label-sm !text-[0.6rem]">系统终端</span>
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></div>
          </div>
          <div className="h-40 overflow-y-auto scrollbar-hide space-y-2 font-mono text-[10px] text-slate-500">
            {systemLogs.map((log, i) => (
              <div key={i} className="flex gap-2 leading-tight">
                <span className="text-slate-800 shrink-0">{log.ts}</span>
                <span className={log.msg.includes('❌') ? 'text-rose-400' : 'text-slate-400'}>{log.msg}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
