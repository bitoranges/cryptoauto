
import { GoogleGenAI, Type, Modality, LiveServerMessage } from "@google/genai";
import { Signal, Domain, SignalType, VerificationStatus, Lane, Track, PublishLevel, Stance, Draft, GroundingChunk } from "../types";
import { WHITELIST_DOMAINS } from "../constants";

export async function validateUrl(url: string): Promise<{ valid: boolean; tier: string; reason?: string }> {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.toLowerCase();
    
    if (WHITELIST_DOMAINS.OFFICIAL.some(d => domain.includes(d))) return { valid: true, tier: "1" };
    if (WHITELIST_DOMAINS.TIER1.some(d => domain.includes(d))) return { valid: true, tier: "2" };
    if (WHITELIST_DOMAINS.TIER2.some(d => domain.includes(d))) return { valid: true, tier: "3" };
    
    if (domain.includes("test.com") || domain.includes("example.com")) {
      return { valid: false, tier: "4", reason: "Invalid Domain" };
    }

    return { valid: true, tier: "4" };
  } catch (e) {
    return { valid: false, tier: "4", reason: "Malformed URL" };
  }
}

export function getUrlTier(url: string): string {
  try {
    const domain = new URL(url).hostname;
    if (WHITELIST_DOMAINS.OFFICIAL.some(d => domain.includes(d))) return "1";
    if (WHITELIST_DOMAINS.TIER1.some(d => domain.includes(d))) return "2";
    if (WHITELIST_DOMAINS.TIER2.some(d => domain.includes(d))) return "3";
    return "4";
  } catch {
    return "4";
  }
}

export async function classifySignal(content: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `请分类以下原始信息并提取关键元数据（使用中文回复）: "${content}"`,
    config: {
      systemInstruction: "你是一个专业的加密货币与AI情报分类器。请准确识别领域、子赛道（如DeFi, L2, AI Infra, Meme, GameFi等）、类型和紧迫性。",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING, description: "信号的主题摘要（中文）" },
          domain: { type: Type.STRING, enum: Object.values(Domain) },
          sub_sector: { type: Type.STRING, description: "所属子赛道标签" },
          signal_type: { type: Type.STRING, enum: Object.values(SignalType) },
          time_sensitivity: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
          discussion_level: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
          entities: { type: Type.ARRAY, items: { type: Type.STRING } },
          initial_risk: { type: Type.STRING }
        },
        required: ['topic', 'domain', 'signal_type', 'entities']
      }
    }
  });
  return JSON.parse(response.text || '{}');
}

export async function verifyClaims(topic: string, entities: string[]) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `请核实以下主题的真实性及最新进展: ${topic}，涉及实体: ${entities.join(', ')}。请搜索官方公告或声誉良好的媒体报道。`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  const metadata = response.candidates?.[0]?.groundingMetadata;
  const groundingChunks: GroundingChunk[] = metadata?.groundingChunks?.map((chunk: any) => ({
    text: chunk.web?.title || "Search Result",
    uri: chunk.web?.uri,
    relevance: 1.0 
  })) || [];

  const urls = groundingChunks.map(c => c.uri).filter((u): u is string => !!u);

  return {
    verdict_text: response.text,
    sources: urls,
    grounding_chunks: groundingChunks,
    status: urls.length > 0 ? VerificationStatus.CONFIRMED : VerificationStatus.PARTIAL,
    confidence: urls.length > 0 ? 0.95 : 0.5,
    what_would_confirm: "建议查看该项目官方 X 账号或 Discord 公告频道进行最终确认。"
  };
}

export async function supplementalVerification(signalTopic: string, query: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `深度核验任务 [${signalTopic}]: ${query}。请在互联网上搜索最精确、最新的数据支持。`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  const metadata = response.candidates?.[0]?.groundingMetadata;
  const chunks: GroundingChunk[] = metadata?.groundingChunks?.map((chunk: any) => ({
    text: chunk.web?.title || "Depth Search",
    uri: chunk.web?.uri,
    relevance: 1.0
  })) || [];

  return {
    text: response.text,
    chunks: chunks
  };
}

export async function analyzeImpact(topic: string, content: string, historySummary: string = "") {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = historySummary 
    ? `该事件最近7天的历史摘要如下: "${historySummary}"。
       现在发生了新进展: "${content}"。
       请分析本次进展带来的【关键变化点】、市场影响及叙事走向。`
    : `请分析该事件的市场与叙事影响: "${topic}"。内容: "${content}"。`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: "你是一位资深加密市场分析师。必须明确指出新进展与历史信息的不同之处。请使用中文输出。此外，请提供一个 1-10 的 Alpha 评分、具体战略建议、叙事向心力评分（0-1），以及【证伪条件】（什么情况会让你改变观点）。",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          key_changes: { type: Type.STRING },
          market_impact: { type: Type.STRING },
          narrative_impact: { type: Type.STRING },
          affected_assets: { type: Type.ARRAY, items: { type: Type.STRING } },
          stance: { type: Type.STRING, enum: Object.values(Stance) },
          stance_reasoning: { type: Type.STRING },
          recommended_action: { type: Type.STRING },
          alpha_score: { type: Type.NUMBER },
          narrative_affinity: { type: Type.NUMBER },
          what_would_change_mind: { type: Type.STRING }
        },
        required: ['key_changes', 'market_impact', 'narrative_impact', 'affected_assets', 'stance', 'recommended_action', 'alpha_score', 'narrative_affinity', 'what_would_change_mind']
      }
    }
  });
  return JSON.parse(response.text || '{}');
}

export async function judgeSignal(classification: any, verification: any, analysis: any) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `综合研判：
    核实状态: ${verification.status} (置信度: ${verification.confidence})
    分析立场: ${analysis.stance} (Alpha: ${analysis.alpha_score})
    子赛道: ${classification.sub_sector}`,
    config: {
      systemInstruction: `你是一位风控裁判。请根据核实器的“事实事实”和分析器的“影响预测”进行终审。如果两者存在分歧（例如事实存疑但分析乐观），请生成一段【Agent 辩论摘要】(agent_debate) 描述分歧点。同时判定发布路由与社交预测。`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          lane: { type: Type.STRING, enum: Object.values(Lane) },
          track: { type: Type.STRING, enum: Object.values(Track) },
          publish_level: { type: Type.STRING, enum: Object.values(PublishLevel) },
          risk_score: { type: Type.NUMBER },
          risk_notes: { type: Type.ARRAY, items: { type: Type.STRING } },
          required_labels: { type: Type.ARRAY, items: { type: Type.STRING } },
          projected_reach: { type: Type.STRING, enum: ['low', 'medium', 'high', 'viral'] },
          agent_debate: { type: Type.STRING, description: "描述核实器与分析器之间的分歧点（中文）" }
        },
        required: ['lane', 'track', 'publish_level', 'risk_score', 'projected_reach']
      }
    }
  });
  return JSON.parse(response.text || '{}');
}

export async function generatePolishedDraft(signal: Signal, analysis: any, feedback?: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const isResearch = signal.routing.track === Track.RESEARCH;
  
  const prompt = feedback 
    ? `原始信号: ${signal.topic}。分析结论: ${analysis.market_impact}。用户反馈修改要求: "${feedback}"。请根据反馈重写文案。`
    : `信号主题: ${signal.topic}。关键事实: ${analysis.key_changes}。分析建议: ${analysis.market_impact}。立场: ${analysis.stance}。`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: `你是一位专业的 Twitter/X 文案专家。严格遵守事实，不喊单。${isResearch ? '因为是 RESEARCH 赛道，请生成 3-5 条推文的系列大纲。必须提供深入的反面论证(counter_case)。' : '简明扼要。'}`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          content: { type: Type.STRING },
          labels: { type: Type.ARRAY, items: { type: Type.STRING } },
          counter_case: { type: Type.STRING },
          fact_checksum: { type: Type.STRING }
        },
        required: ['content', 'labels', 'counter_case', 'fact_checksum']
      }
    }
  });
  return JSON.parse(response.text || '{}');
}

export async function distillStory(story: any, signals: Signal[]) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const context = signals.map(s => `[${s.created_at}] ${s.topic}: ${s.analysis_output?.market_impact}`).join('\n');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `叙事故事线演进过程:\n${context}\n\n提取简报：驱动力、博弈方、确定性、黑天鹅。`,
    config: {
      systemInstruction: "你是一位加密研究员。请撰写深度简报。使用中文。",
    }
  });
  return response.text;
}

export async function generateDeepDiveReport(storyTitle: string, distilledNote: string, signals: Signal[]) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const signalSummary = signals.map(s => `- ${s.topic} (${s.analysis_output?.stance})`).join('\n');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `基于叙事 "${storyTitle}" 的以下信号和摘要生成深度研报：
    信号列表：
    ${signalSummary}
    
    摘要：
    ${distilledNote}`,
    config: {
      systemInstruction: "你是一位顶级加密研究机构的首席分析师。请撰写一份结构精美、论点犀利的研报。使用 Markdown 格式。",
    }
  });
  return response.text;
}

/**
 * AI 生成叙事视频 (Veo)
 */
export async function generateStoryVideo(title: string, summary: string): Promise<string | undefined> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: `A dramatic cinematic news teaser for a crypto story: "${title}". ${summary}. Cyberpunk aesthetics, high contrast, professional transitions, 1080p.`,
    config: {
      numberOfVideos: 1,
      resolution: '1080p',
      aspectRatio: '16:9'
    }
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) return undefined;

  const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await videoResponse.blob();
  return URL.createObjectURL(blob);
}

/**
 * Gemini Live 审计会话
 */
export function connectLiveAudit(signal: Signal, callbacks: any) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
      },
      systemInstruction: `你是一个批判性的加密审计员。用户正在审查一个关于 [${signal.topic}] 的情报。
      背景：
      - 领域：${signal.domain}
      - 赛道：${signal.sub_sector}
      - 分析立场：${signal.analysis_output?.stance}
      - 市场影响：${signal.analysis_output?.market_impact}
      你的任务是以对话方式协助用户审计该信号。如果用户询问证据，请引用其 Grounding 数据。语气应专业、犀利。`,
    },
  });
}

/**
 * Helper: Encode Float32 PCM to Int16 Base64
 */
export function createAudioBlob(data: Float32Array): { data: string, mimeType: string } {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  const bytes = new Uint8Array(int16.buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return {
    data: btoa(binary),
    mimeType: 'audio/pcm;rate=16000',
  };
}

export function decodeBase64(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioToBuffer(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const numChannels = 1;
  const sampleRate = 24000;
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export async function generateStoryPoster(title: string, summary: string): Promise<string | undefined> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: `A futuristic, cyberpunk style cinematic poster for a crypto news story titled: "${title}". Summary: "${summary}". Dark theme, neon accents, 4k.`, }],
    },
    config: { imageConfig: { aspectRatio: "16:9" } },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  return undefined;
}
